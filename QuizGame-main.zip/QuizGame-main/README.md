# QuizGame
This is a static website with a login &amp; signup page followed by a Quiz game.
